#!/bin/sh
# 只用于已有本项目硬件初始化环境的板卡；不删除出厂驱动/脚本。
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST=/opt/zxjb14a-monitor-c/1.9.1-dev
if ! grep -Eq '"site_mapping_confirmed"[[:space:]]*:[[:space:]]*true' "$HERE/monitor.site.json"; then
    echo '请先核对箱地址、板序/通道、CAN线路和串口参数，再将site_mapping_confirmed改成true。'
    exit 2
fi
systemctl cat zxjb14a-hardware-prepare.service >/dev/null
systemctl disable --now zxjb14a-monitor-c.service || true
systemctl disable --now zxjb14a-gateway.service
if pidof zxjb14a_monitor_c >/dev/null 2>&1; then
    echo '有手动运行的新程序，请先核对PID并停止；未覆盖程序。'
    exit 3
fi
mkdir -p "$DEST" /var/lib/zxjb14a-monitor-c
if [ -f "$DEST/monitor.site.json" ]; then
    cp "$DEST/monitor.site.json" "$DEST/monitor.site.json.backup.$(date +%s)"
fi
cp "$HERE/zxjb14a_monitor_c" "$DEST/zxjb14a_monitor_c.upload"
chmod 755 "$DEST/zxjb14a_monitor_c.upload"
"$DEST/zxjb14a_monitor_c.upload" --config "$HERE/monitor.site.json" --check-config
mv "$DEST/zxjb14a_monitor_c.upload" "$DEST/zxjb14a_monitor_c"
cp "$HERE/monitor.site.json" "$DEST/monitor.site.json"
chmod 644 "$DEST/monitor.site.json"
cp "$HERE/zxjb14a-monitor-c.service" /etc/systemd/system/zxjb14a-monitor-c.service
chmod 644 /etc/systemd/system/zxjb14a-monitor-c.service
systemctl daemon-reload
echo '安装完成，服务使用monitor.site.json；尚未启动/开启自启。'
echo '可直接启动或设置自启；无对端时新版按退避等待，对端上线后自动恢复。'
