# C 1.9.1-dev 第1块板：通道1-8

箱地址11（十进制），本板485物理口1～8对应协议通道1-8。串口路径USB0～USB7不变。
双CAN can0/can1，初始250K，485为9600/8N1。07已开启；速率只改收到请求的那一路。
程序二进制与原1.9.1-dev一致。无源码包，不需要重新编译。

## 部署

只用于已有本项目驱动及zxjb14a-hardware-prepare.service的板卡。请按板序选择一个包部署，每块板只运行一个服务。

```sh
cd /opt
tar -xzvf c-1.9.1-dev-1-8.tar.gz
cd c-1.9.1-dev-1-8
sha256sum -c SHA256SUMS
# 如不在1号采集箱，在下面JSON中改device_address为12～17
vi monitor.site.json
# 检查曾经为本组通道保存的07状态；已有状态会覆盖主JSON，先停服务再处理
./zxjb14a_monitor_c --config monitor.site.json --check-config
sh install-outside.sh
systemctl enable --now zxjb14a-monitor-c
systemctl status zxjb14a-monitor-c -l --no-pager
```

校验应在编辑配置之前。当前默认site_mapping_confirmed=true，安装前仍需核对实物接线和板序。
安装目录仍为/opt/zxjb14a-monitor-c/1.9.1-dev，服务使用此处monitor.site.json；安装后改解压目录的JSON不会自动改变运行配置。

## 07持久参数

runtime路径：/var/lib/zxjb14a-monitor-c/runtime-1.9.1-07-ch1-8.json
速率状态路径：/var/lib/zxjb14a-monitor-c/can-rates-1.9.1-07-ch1-8

本包使用按通道组区分的状态文件，不沿用原通用07状态文件；首次安装若本组文件不存在，采用本包通道/箱地址/周期和初始250K。
同组重装仍会加载已有本组状态。换箱、重新分组前停服务并备份核对这两个文件，不要盲删；上位机速率也需匹配。
同箱共址的全局07参数可能作用于多块板，不可用通道字段把速率/箱地址/周期设置限定为某一块板。详见随包07文档。

安装脚本停止并禁用出厂业务，保留驱动/硬件初始化；最后需自行enable --now开启新服务。
本次仅配置/脚本/包校验，无实板部署或多板硬件验收。

公开版已移除设备与寄存器清单，只保留通用配置。
